package com.example.meu_ajudante_fg

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
