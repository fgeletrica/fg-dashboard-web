import 'package:flutter/material.dart';
import '../../../core/app_theme.dart';
import '../models/industrial_models.dart';
import '../models/shift_summary.dart';
import '../services/industrial_store.dart';

class IndustrialDashboardScreen extends StatefulWidget {
  const IndustrialDashboardScreen({super.key});

  @override
  State<IndustrialDashboardScreen> createState() => _IndustrialDashboardScreenState();
}

class _IndustrialDashboardScreenState extends State<IndustrialDashboardScreen> {
  DateTimeRange? _range;
  String _shift = 'ALL';

  Future<DateTimeRange?> _pickRange() async {
    final now = DateTime.now();
    final initial = _range ??
        DateTimeRange(
          start: DateTime(now.year, now.month, now.day, 0, 0),
          end: now,
        );
    return showDateRangePicker(
      context: context,
      firstDate: DateTime(now.year - 1),
      lastDate: DateTime(now.year + 1),
      initialDateRange: initial,
    );
  }

  DateTimeRange _effectiveRange() {
    final now = DateTime.now();
    return _range ??
        DateTimeRange(
          start: DateTime(now.year, now.month, now.day, 0, 0),
          end: now,
        );
  }

  @override
  Widget build(BuildContext context) {
    final rr = _effectiveRange();

    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        backgroundColor: AppTheme.bg,
        title: const Text('Supervisor • Dashboard'),
        actions: [
          IconButton(
            tooltip: 'Período',
            onPressed: () async {
              final picked = await _pickRange();
              if (!mounted) return;
              setState(() => _range = picked);
            },
            icon: const Icon(Icons.date_range),
          ),
        ],
      ),
      body: FutureBuilder<List<LineStopReport>>(
        future: IndustrialStore.listLineStops(limit: 2000),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());

          final all = snap.data ?? const <LineStopReport>[];
          final filtered = IndustrialStore.filterLineStops(
            all,
            start: rr.start,
            end: rr.end,
            shift: _shift,
            query: '',
          );

          final totalStops = filtered.length;
          final totalDown = IndustrialStore.sumDowntime(filtered);

          final byMachineDown = IndustrialStore.downtimeByMachine(filtered);
          final byCauseCount = IndustrialStore.countByCause(filtered);

          final topMachine = IndustrialStore.topKey(byMachineDown);
          final topCause = IndustrialStore.topKey(byCauseCount);

          final topMachines = IndustrialStore.topN(byMachineDown, n: 5);
          final topCauses = IndustrialStore.topN(byCauseCount, n: 5);

          final heat = IndustrialStore.downtimeHeatByHour(filtered);
          final maxHeat = heat.isEmpty ? 1 : (heat.reduce((a, b) => a > b ? a : b));
          final rangeLabel = '${rr.start.toString().substring(0, 10)} → ${rr.end.toString().substring(0, 10)}';

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _filters(rangeLabel),
              const SizedBox(height: 12),

              Row(
                children: [
                  Expanded(child: _kpi('Paradas', '$totalStops')),
                  const SizedBox(width: 10),
                  Expanded(child: _kpi('Downtime', '${totalDown}min')),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _kpi('Top máquina', topMachine.isEmpty ? '—' : topMachine)),
                  const SizedBox(width: 10),
                  Expanded(child: _kpi('Top causa', topCause.isEmpty ? '—' : topCause)),
                ],
              ),

              const SizedBox(height: 16),
              _sectionTitle('Heatmap • Downtime por hora'),
              const SizedBox(height: 10),
              _heatmap(heat, maxHeat),

              const SizedBox(height: 16),
              _sectionTitle('Ranking • Máquinas (downtime)'),
              const SizedBox(height: 10),
              ...topMachines.map((e) => _rankRow(e.key.isEmpty ? '—' : e.key, '${e.value}min')),

              const SizedBox(height: 16),
              _sectionTitle('Ranking • Causas (quantidade)'),
              const SizedBox(height: 10),
              ...topCauses.map((e) => _rankRow(e.key.isEmpty ? '—' : e.key, '${e.value}x')),

              const SizedBox(height: 16),
              _sectionTitle('Fechamentos salvos (Turnos)'),
              const SizedBox(height: 10),
              FutureBuilder<List<ShiftSummary>>(
                future: IndustrialStore.listShiftSummaries(limit: 12),
                builder: (context, s2) {
                  if (!s2.hasData) return const Center(child: Padding(padding: EdgeInsets.all(16), child: CircularProgressIndicator()));
                  final list = s2.data ?? const <ShiftSummary>[];
                  if (list.isEmpty) {
                    return Text(
                      'Ainda não fechou nenhum turno.',
                      style: TextStyle(color: Colors.white.withOpacity(.7), fontWeight: FontWeight.w700),
                    );
                  }
                  return Column(
                    children: list.map((s) {
                      final dt = DateTime.fromMillisecondsSinceEpoch(s.ts).toString().substring(0, 16);
                      return _card(
                        child: Row(
                          children: [
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(
                                  'Turno ${s.shift} • $dt',
                                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  'Paradas: ${s.totalStops} • Downtime: ${s.downtimeMin}min',
                                  style: TextStyle(color: Colors.white.withOpacity(.7), fontWeight: FontWeight.w700),
                                ),
                                const SizedBox(height: 3),
                                Text(
                                  'Top máquina: ${s.topMachine.isEmpty ? '—' : s.topMachine} • Top causa: ${s.topCause.isEmpty ? '—' : s.topCause}',
                                  style: TextStyle(color: Colors.white.withOpacity(.65), fontWeight: FontWeight.w700),
                                ),
                              ]),
                            ),
                            Icon(Icons.chevron_right, color: Colors.white.withOpacity(.6)),
                          ],
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _filters(String rangeLabel) {
    return _card(
      child: Row(
        children: [
          Expanded(
            child: Text(
              'Período: $rangeLabel',
              style: TextStyle(color: Colors.white.withOpacity(.85), fontWeight: FontWeight.w800),
            ),
          ),
          const SizedBox(width: 10),
          DropdownButton<String>(
            value: _shift,
            dropdownColor: AppTheme.card,
            items: const [
              DropdownMenuItem(value: 'ALL', child: Text('Todos')),
              DropdownMenuItem(value: 'A', child: Text('Turno A')),
              DropdownMenuItem(value: 'B', child: Text('Turno B')),
              DropdownMenuItem(value: 'C', child: Text('Turno C')),
              DropdownMenuItem(value: 'D', child: Text('Turno D')),
            ],
            onChanged: (v) => setState(() => _shift = v ?? 'ALL'),
          ),
        ],
      ),
    );
  }

  Widget _kpi(String title, String value) {
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(color: Colors.white.withOpacity(.7), fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18),
          ),
        ],
      ),
    );
  }

  Widget _sectionTitle(String s) {
    return Text(s, style: TextStyle(color: Colors.white.withOpacity(.9), fontWeight: FontWeight.w900));
  }

  Widget _rankRow(String left, String right) {
    return _card(
      child: Row(
        children: [
          Expanded(child: Text(left, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
          Text(right, style: TextStyle(color: Colors.white.withOpacity(.75), fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }

  Widget _heatmap(List<int> heat, int maxHeat) {
    // 24 horas
    final data = (heat.length == 24) ? heat : List<int>.filled(24, 0);
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('0h → 23h', style: TextStyle(color: Colors.white.withOpacity(.7), fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: List.generate(24, (i) {
              final v = data[i];
              final ratio = maxHeat <= 0 ? 0.0 : (v / maxHeat).clamp(0.0, 1.0);
              final bg = Color.lerp(AppTheme.card, AppTheme.gold.withOpacity(.85), ratio) ?? AppTheme.card;

              return Container(
                width: 44,
                height: 34,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: bg,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: AppTheme.border.withOpacity(.35)),
                ),
                child: Text(
                  '$i',
                  style: TextStyle(color: Colors.white.withOpacity(.9), fontWeight: FontWeight.w900),
                ),
              );
            }),
          ),
          const SizedBox(height: 10),
          Text(
            'Mais “quente” = mais downtime.',
            style: TextStyle(color: Colors.white.withOpacity(.6), fontWeight: FontWeight.w700),
          ),
        ],
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppTheme.border.withOpacity(.35)),
      ),
      child: child,
    );
  }
}
