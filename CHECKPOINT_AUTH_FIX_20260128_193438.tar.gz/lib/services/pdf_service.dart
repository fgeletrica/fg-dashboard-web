import 'dart:io';
import 'package:share_plus/share_plus.dart';

import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/budget_models.dart';
import '../models/report_models.dart';

class PdfService {
  static final _fmt = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');

  static String _money(num v) => _fmt.format(v);

  static String _dt(DateTime d) {
    try {
      return DateFormat('dd/MM/yyyy HH:mm', 'pt_BR').format(d);
    } catch (_) {
      return d.toIso8601String();
    }
  }

  /// ✅ Versão SAFE: gera PDF do orçamento SEM fotos.
  /// (Fotos estavam quebrando a compilação e a renderização no pdf/widgets)
  static Future<File> generateBudgetPdf({required BudgetDoc doc}) async {
    final pdf = pw.Document();

    pdf.addPage(
      pw.MultiPage(
        pageTheme: _pageTheme(),
        build: (context) {
          final content = <pw.Widget>[
            pw.Text(
              'ORÇAMENTO',
              style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 8),
            pw.Text('Cliente: ${doc.clientName}'),
            pw.Text('Data: ${_dt(doc.createdAt)}'),
            pw.SizedBox(height: 12),
            if ((doc.originTitle ?? '').trim().isNotEmpty) ...[
              pw.Text(
                'Origem do cálculo',
                style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
              ),
              pw.Text('Equipamento: ${doc.originTitle}'),
              pw.Text(
                  'Potência: ${doc.originPowerW?.toStringAsFixed(0) ?? '—'} W'),
              pw.Text('Tensão: ${doc.originVoltage ?? '—'} V'),
              pw.Text(
                  'Distância: ${doc.originDistanceM?.toStringAsFixed(1) ?? '—'} m'),
              pw.SizedBox(height: 12),
            ],
            pw.Text(
              'Materiais',
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 6),
            if (doc.materials.isEmpty)
              pw.Text('—')
            else
              pw.Table.fromTextArray(
                headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                headerDecoration:
                    const pw.BoxDecoration(color: PdfColors.grey300),
                cellAlignment: pw.Alignment.centerLeft,
                data: <List<String>>[
                  <String>['Item', 'Qtd', 'Un', 'Unit', 'Total'],
                  ...doc.materials.map((m) => <String>[
                        m.name,
                        m.qty.toStringAsFixed(2),
                        m.unit,
                        _money(m.unitPrice),
                        _money(m.total),
                      ]),
                ],
              ),
            pw.SizedBox(height: 12),
            pw.Text(
              'Serviços',
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 6),
            if (doc.services.isEmpty)
              pw.Text('—')
            else
              pw.Table.fromTextArray(
                headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                headerDecoration:
                    const pw.BoxDecoration(color: PdfColors.grey300),
                cellAlignment: pw.Alignment.centerLeft,
                data: <List<String>>[
                  <String>['Serviço', 'Valor'],
                  ...doc.services.map((s) => <String>[
                        s.name,
                        _money(s.price),
                      ]),
                ],
              ),
            pw.SizedBox(height: 12),
            pw.Divider(),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('Subtotal materiais:'),
                pw.Text(_money(doc.subtotalMaterials)),
              ],
            ),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('Subtotal serviços:'),
                pw.Text(_money(doc.subtotalServices)),
              ],
            ),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('Margem:'),
                pw.Text(_money(doc.marginAmount)),
              ],
            ),
            pw.SizedBox(height: 6),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('TOTAL',
                    style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
                pw.Text(_money(doc.total),
                    style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              ],
            ),
            pw.SizedBox(height: 16),
            pw.Text(
              'Assinatura',
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
            ),
            pw.SizedBox(height: 24),
            pw.Container(
              height: 1,
              color: PdfColors.grey600,
            ),
            pw.SizedBox(height: 6),
            pw.Text('Cliente'),
            pw.SizedBox(height: 16),
          ];

          // watermark FREE (se quiser manter sempre, deixa fixo.
          // Se quiser condicionar pelo hasPro no futuro, a gente liga depois.)
          return [
            pw.Stack(
              children: [
                pw.Positioned.fill(
                  child: pw.Center(
                    child: pw.Transform.rotate(
                      angle: -0.5,
                      child: pw.Opacity(
                        opacity: 0.10,
                        child: pw.Text(
                          'FG ELÉTRICA • FREE',
                          style: pw.TextStyle(
                            fontSize: 56,
                            fontWeight: pw.FontWeight.bold,
                            color: PdfColors.grey600,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                pw.Column(children: content),
              ],
            ),
          ];
        },
        footer: (context) => pw.Container(
          alignment: pw.Alignment.centerRight,
          padding: const pw.EdgeInsets.only(top: 10),
          child: pw.Text(
            'Página ${context.pageNumber} / ${context.pagesCount}',
            style: pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
          ),
        ),
      ),
    );

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/orcamento_${doc.id}.pdf');
    await file.writeAsBytes(await pdf.save());
    return file;
  }

  static pw.PageTheme _pageTheme() {
    return pw.PageTheme(
      pageFormat: PdfPageFormat.a4,
      margin: const pw.EdgeInsets.symmetric(horizontal: 28, vertical: 28),
      theme: pw.ThemeData.withFont(
        base: pw.Font.helvetica(),
        bold: pw.Font.helveticaBold(),
      ),
    );
  }

  
  // =========================
  // Queda de Tensão (Relatório PDF)
  // =========================
  static Future<File> generateVoltageDropPdf({
    required Map<String, dynamic> data,
    required bool hasPro,
  }) async {
    final pdf = pw.Document();

    final title = (data['title'] ?? 'Relatório — Queda de Tensão').toString();

    List<pw.Widget> page(pw.Context context) {
      final w = <pw.Widget>[
        pw.Text(
          title,
          style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
        ),
        pw.SizedBox(height: 8),
        pw.Text('Data: ${data['date'] ?? ''}'),
        pw.SizedBox(height: 12),
        pw.Text('Entradas', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        pw.Bullet(text: 'Tensão: ${data['voltage']} V'),
        pw.Bullet(text: 'Fases: ${data['phases']}'),
        pw.Bullet(text: 'Distância (ida): ${data['distanceM']} m'),
        pw.Bullet(text: 'Material: ${data['material']}'),
        pw.Bullet(text: 'FP: ${data['pf']}'),
        pw.Bullet(text: 'Queda máx: ${data['vdMaxPercent']} %'),
        pw.Bullet(text: 'Corrente: ${data['currentA']} A'),
        pw.Bullet(text: 'Potência: ${data['powerW']} W'),
        pw.SizedBox(height: 12),
        pw.Text('Resultado', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 6),
        pw.Text('Seção sugerida: ${data['sectionMm2']} mm²'),
        pw.Text('Queda estimada: ${data['vdPercent']} %'),
        pw.SizedBox(height: 12),
        pw.Divider(),
        pw.Text(
          hasPro ? 'PRO (sem marca d’água)' : 'FREE — Relatório com marca d’água',
          style: pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
        ),
      ];
      return w;
    }

    pdf.addPage(
      pw.MultiPage(
        pageTheme: _pageTheme(),
        build: (context) {
          final content = page(context);
          if (hasPro) return content;

          // watermark FREE
          return [
            pw.Stack(
              children: [
                pw.Positioned.fill(
                  child: pw.Center(
                    child: pw.Transform.rotate(
                      angle: -0.5,
                      child: pw.Opacity(
                        opacity: 0.10,
                        child: pw.Text(
                          'FG ELÉTRICA • FREE',
                          style: pw.TextStyle(
                            fontSize: 56,
                            fontWeight: pw.FontWeight.bold,
                            color: PdfColors.grey600,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                pw.Column(children: content),
              ],
            ),
          ];
        },
        footer: (context) => pw.Container(
          alignment: pw.Alignment.centerRight,
          padding: const pw.EdgeInsets.only(top: 10),
          child: pw.Text(
            'Página ${context.pageNumber} / ${context.pagesCount}',
            style: pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
          ),
        ),
      ),
    );

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/relatorio_queda_tensao_${DateTime.now().millisecondsSinceEpoch}.pdf');
    await file.writeAsBytes(await pdf.save());
    return file;
  }


  // =========================
  // Wrappers (compat)
  // =========================
  static Future<void> openPdf(dynamic fileOrPath) async {
    try {
      final path =
          (fileOrPath is File) ? fileOrPath.path : fileOrPath?.toString();
      if (path == null || path.isEmpty) return;

      if (Platform.isLinux) {
        await Process.run('xdg-open', [path]);
        return;
      }
      if (Platform.isMacOS) {
        await Process.run('open', [path]);
        return;
      }
      if (Platform.isWindows) {
        await Process.run('cmd', ['/c', 'start', '', path]);
        return;
      }
    } catch (_) {}
  }

  static Future<void> sharePdf(dynamic fileOrPath) async {
    try {
      final path =
          (fileOrPath is File) ? fileOrPath.path : fileOrPath?.toString();
      if (path == null || path.isEmpty) return;

      await Share.shareXFiles([XFile(path)], text: 'Orçamento (PDF)');
    } catch (_) {}
  }

  // =========================
  // LAUDO TÉCNICO (PDF)
  // =========================
  static Future<File> generateTechnicalReportPdf({
    required TechnicalReportDoc doc,
    required bool hasPro,
  }) async {
    final pdf = pw.Document();

    final header = pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(doc.title.isEmpty ? 'LAUDO TÉCNICO' : doc.title.toUpperCase(),
            style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 8),
        pw.Text('Cliente: ${doc.clientName.isEmpty ? '—' : doc.clientName}'),
        pw.Text('Endereço: ${doc.address.isEmpty ? '—' : doc.address}'),
        pw.Text('Data: ${_dt(doc.createdAt)}'),
      ],
    );

    pw.Widget watermark(pw.Widget child) {
      if (hasPro) return child;
      return pw.Stack(children: [
        child,
        pw.Positioned.fill(
          child: pw.Center(
            child: pw.Transform.rotate(
              angle: -0.45,
              child: pw.Opacity(
                opacity: 0.10,
                child: pw.Text(
                  'FG ELÉTRICA • FREE',
                  style: pw.TextStyle(
                    fontSize: 56,
                    fontWeight: pw.FontWeight.bold,
                    color: PdfColors.grey600,
                  ),
                ),
              ),
            ),
          ),
        ),
      ]);
    }

    pdf.addPage(
      pw.MultiPage(
        pageTheme: _pageTheme(),
        build: (context) {
          final parts = <pw.Widget>[
            header,
            pw.SizedBox(height: 12),
            pw.Divider(),
            pw.SizedBox(height: 8),

            pw.Text('Descrição do chamado', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 6),
            pw.Text(doc.description.isEmpty ? '—' : doc.description),
            pw.SizedBox(height: 12),

            pw.Text('Constatações / diagnóstico', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 6),
            pw.Text(doc.findings.isEmpty ? '—' : doc.findings),
            pw.SizedBox(height: 12),

            pw.Text('Recomendações', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 6),
            pw.Text(doc.recommendations.isEmpty ? '—' : doc.recommendations),
          ];

          // bloco opcional de queda de tensão
          final hasVD = (doc.vdPercent != null || doc.vdVolts != null);
          if (hasVD) {
            parts.addAll([
              pw.SizedBox(height: 14),
              pw.Divider(),
              pw.SizedBox(height: 8),
              pw.Text('Anexo — Queda de tensão', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
              pw.SizedBox(height: 6),
              pw.Table.fromTextArray(
                headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
                cellAlignment: pw.Alignment.centerLeft,
                data: <List<String>>[
                  <String>['Campo', 'Valor'],
                  <String>['Tensão', doc.voltageV == null ? '—' : '${doc.voltageV!.toStringAsFixed(0)} V'],
                  <String>['Fases', doc.phases == null ? '—' : (doc.phases == 3 ? 'Trifásico' : 'Monofásico')],
                  <String>['Potência', doc.powerW == null ? '—' : '${doc.powerW!.toStringAsFixed(0)} W'],
                  <String>['Corrente', doc.currentA == null ? '—' : '${doc.currentA!.toStringAsFixed(2)} A'],
                  <String>['Comprimento', doc.lengthM == null ? '—' : '${doc.lengthM!.toStringAsFixed(1)} m'],
                  <String>['Seção', doc.sectionMm2 == null ? '—' : '${doc.sectionMm2!.toStringAsFixed(1)} mm²'],
                  <String>['Queda (%)', doc.vdPercent == null ? '—' : '${doc.vdPercent!.toStringAsFixed(2)} %'],
                  <String>['Queda (V)', doc.vdVolts == null ? '—' : '${doc.vdVolts!.toStringAsFixed(2)} V'],
                ],
              ),
            ]);
          }

          parts.addAll([
            pw.SizedBox(height: 18),
            pw.Text('Assinatura', style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 24),
            pw.Container(height: 1, color: PdfColors.grey600),
            pw.SizedBox(height: 6),
            pw.Text('Responsável técnico'),
          ]);

          return [ watermark(pw.Column(children: parts)) ];
        },
        footer: (context) => pw.Container(
          alignment: pw.Alignment.centerRight,
          padding: const pw.EdgeInsets.only(top: 10),
          child: pw.Text(
            'Página ${context.pageNumber} / ${context.pagesCount}',
            style: pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
          ),
        ),
      ),
    );

    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/laudo_${doc.id}.pdf');
    await file.writeAsBytes(await pdf.save());
    return file;
  }


}
