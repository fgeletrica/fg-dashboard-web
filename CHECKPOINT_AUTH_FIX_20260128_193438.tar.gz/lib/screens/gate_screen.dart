import 'package:flutter/material.dart';
import '../services/profile_store.dart';
import 'home_screen.dart';
import 'profile_setup_screen.dart';

class GateScreen extends StatefulWidget {
  const GateScreen({super.key});

  @override
  State<GateScreen> createState() => _GateScreenState();
}

class _GateScreenState extends State<GateScreen> {
  bool loading = true;
  bool hasProfile = false;

  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final p = await ProfileStore.get();
    final ok = p.name.trim().isNotEmpty && p.name.trim() != 'Felype Guimarães';
    if (!mounted) return;
    setState(() {
      hasProfile = ok;
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (hasProfile) return const HomeScreen();

    return ProfileSetupScreen(
      onDone: () async {
        await _check();
        if (!mounted) return;
        setState(() {});
      },
    );
  }
}
