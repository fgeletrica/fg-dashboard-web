import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import 'industrial_home_screen.dart';

class IndustrialGateScreen extends StatelessWidget {
  const IndustrialGateScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        backgroundColor: AppTheme.bg,
        elevation: 0,
        title: const Text('Modo Industrial'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.card,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: AppTheme.border.withOpacity(.35)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(.06),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: Colors.white.withOpacity(.12)),
                        ),
                        child: Icon(Icons.warning_amber_rounded, color: Colors.orangeAccent.withOpacity(.9)),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Text(
                          '🚧 EM DESENVOLVIMENTO',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    'Este módulo ainda está sendo construído.\n'
                    'Pode ter telas incompletas e mudanças no fluxo.\n\n'
                    '✅ Você pode usar para TESTAR.\n'
                    '✅ O Residencial continua sendo o foco principal.',
                    style: TextStyle(color: Colors.white.withOpacity(.78), fontWeight: FontWeight.w700, height: 1.3),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (_) => const IndustrialHomeScreen()),
                  );
                },
                child: const Text('Entrar mesmo assim'),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              height: 46,
              child: OutlinedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Voltar'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
