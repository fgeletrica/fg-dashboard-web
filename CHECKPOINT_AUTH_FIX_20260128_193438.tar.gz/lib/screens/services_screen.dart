import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../routes/app_routes.dart';
import '../services/pro_access.dart';
import '../services/services_store.dart';

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  bool loading = true;
  bool pro = false;

  List<ServiceDbItem> items = [];

  final nameCtrl = TextEditingController();
  final priceCtrl = TextEditingController(text: '0');

  @override
  void initState() {
    super.initState();
    _checkAndLoad();
  }

  @override
  void dispose() {
    nameCtrl.dispose();
    priceCtrl.dispose();
    super.dispose();
  }

  double _toDouble(String s) =>
      double.tryParse(s.replaceAll(',', '.').trim()) ?? 0;

  Future<void> _checkAndLoad() async {
    pro = await ProAccess.hasProAccessNow();
    if (!mounted) return;
    if (!pro) {
      setState(() => loading = false);
      return;
    }
    items = await ServicesStore.load();
    if (!mounted) return;
    setState(() => loading = false);
  }

  Future<void> _reload() async {
    items = await ServicesStore.load();
    if (!mounted) return;
    setState(() {});
  }

  Future<void> _add() async {
    final n = nameCtrl.text.trim();
    final p = _toDouble(priceCtrl.text);
    if (n.isEmpty) return;

    await ServicesStore.add(ServiceDbItem(name: n, price: p));
    nameCtrl.clear();
    priceCtrl.text = '0';
    await _reload();
  }

  Future<void> _del(int i) async {
    await ServicesStore.removeAt(i);
    await _reload();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
          backgroundColor: AppTheme.bg,
          title: const Text('Meus Serviços (PRO)')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : (!pro ? _locked(context) : _content()),
    );
  }

  Widget _locked(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(16),
        margin: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.border.withOpacity(.35)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.lock, color: AppTheme.gold, size: 36),
            const SizedBox(height: 10),
            const Text('Recurso PRO',
                style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            const SizedBox(height: 6),
            Text('Ative o PRO para usar Meus Serviços.',
                style: TextStyle(color: Colors.white.withOpacity(.7))),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.gold,
                  foregroundColor: Colors.black,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () =>
                    Navigator.of(context).pushNamed(AppRoutes.paywall),
                child: const Text('Ver planos',
                    style: TextStyle(fontWeight: FontWeight.w900)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _content() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Cadastrar serviço',
                  style: TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              _field(nameCtrl, 'Nome do serviço'),
              const SizedBox(height: 10),
              _field(priceCtrl, 'Preço (R\$)', number: true),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _add,
                  style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.gold,
                      foregroundColor: Colors.black),
                  child: const Text('Salvar serviço'),
                ),
              )
            ],
          ),
        ),
        const SizedBox(height: 10),
        const Text('Lista',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        if (items.isEmpty)
          Text('Nenhum serviço ainda.',
              style: TextStyle(color: Colors.white.withOpacity(.7))),
        ...items.asMap().entries.map((e) {
          final i = e.key;
          final it = e.value;
          return _card(
            child: Row(
              children: [
                Icon(Icons.handyman, color: AppTheme.gold),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(it.name,
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800)),
                      const SizedBox(height: 2),
                      Text('Preço: R\$ ${it.price.toStringAsFixed(2)}',
                          style:
                              TextStyle(color: Colors.white.withOpacity(.7))),
                    ],
                  ),
                ),
                IconButton(
                    onPressed: () => _del(i),
                    icon: const Icon(Icons.delete_outline)),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _field(TextEditingController c, String hint, {bool number = false}) {
    return TextField(
      controller: c,
      keyboardType: number
          ? const TextInputType.numberWithOptions(decimal: true)
          : TextInputType.text,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.white.withOpacity(.45)),
        filled: true,
        fillColor: AppTheme.card,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: AppTheme.border.withOpacity(.45)),
        ),
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppTheme.border.withOpacity(.35)),
      ),
      child: child,
    );
  }
}
