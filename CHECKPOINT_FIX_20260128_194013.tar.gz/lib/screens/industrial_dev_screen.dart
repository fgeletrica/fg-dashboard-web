import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import 'industrial_home_screen.dart';

class IndustrialDevScreen extends StatelessWidget {
  const IndustrialDevScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        backgroundColor: AppTheme.bg,
        elevation: 0,
        title: const Text('Modo Industrial'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFB00020).withOpacity(.18),
              borderRadius: BorderRadius.circular(18),
              border:
                  Border.all(color: const Color(0xFFB00020).withOpacity(.55)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    color: const Color(0xFFB00020).withOpacity(.22),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                        color: const Color(0xFFB00020).withOpacity(.55)),
                  ),
                  child: const Icon(Icons.construction, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '⚠️ EM DESENVOLVIMENTO',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w900,
                            fontSize: 20),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Esse módulo ainda está em construção.\n'
                        'Pode ter telas incompletas e mudanças.\n\n'
                        '✅ Mesmo assim você já pode TESTAR as funções atuais.',
                        style: TextStyle(
                            color: Colors.white.withOpacity(.88),
                            fontWeight: FontWeight.w700,
                            height: 1.25),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _card(
            title: 'O que já dá pra testar agora',
            bullets: const [
              'LINHA PAROU: registrar ocorrência e copiar relatório.',
              'Diagnóstico por sintoma (árvore rápida).',
              'Falhas recorrentes (base de conhecimento).',
              'Checklists / LOTO (templates + histórico).',
            ],
          ),
          const SizedBox(height: 12),
          _card(
            title: 'O que está entrando (em breve)',
            bullets: const [
              'Mapa da fábrica (Área → Linha → Máquina) estilo HMI.',
              'QR da máquina (abre checklist + histórico direto).',
              'Fechamento de turno com ranking e timeline.',
              'Exportação de relatórios no padrão supervisor.',
            ],
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 52,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.play_arrow),
              label: const Text('TESTAR AGORA (abrir Painel Industrial)'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.gold,
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
              onPressed: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                      builder: (_) => const IndustrialHomeScreen()),
                );
              },
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 48,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.arrow_back),
              label: const Text('Voltar'),
              style: OutlinedButton.styleFrom(
                foregroundColor: Colors.white,
                side: BorderSide(color: Colors.white.withOpacity(.25)),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
              onPressed: () => Navigator.pop(context),
            ),
          ),
        ],
      ),
    );
  }
}

class _card extends StatelessWidget {
  final String title;
  final List<String> bullets;
  const _card({required this.title, required this.bullets});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppTheme.border.withOpacity(.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(
                  color: Colors.white, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          ...bullets.map(
            (b) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('• ',
                      style: TextStyle(
                          color: Colors.white.withOpacity(.9),
                          fontWeight: FontWeight.w900)),
                  Expanded(
                      child: Text(b,
                          style: TextStyle(
                              color: Colors.white.withOpacity(.78),
                              fontWeight: FontWeight.w700))),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
