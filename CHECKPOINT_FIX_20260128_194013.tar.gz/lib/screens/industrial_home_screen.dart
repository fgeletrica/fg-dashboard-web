import 'package:flutter/material.dart';
import '../core/app_theme.dart';
import '../services/app_mode_store.dart';
import 'mode_select_screen.dart';

import '../features/industrial/screens/line_stop_screen.dart';
import '../features/industrial/screens/diagnosis_screen.dart';
import '../features/industrial/screens/knowledge_base_screen.dart';
import '../features/industrial/screens/checklists_screen.dart';

class IndustrialHomeScreen extends StatelessWidget {
  const IndustrialHomeScreen({super.key});

  Future<void> _backToModeSelect(BuildContext context) async {
    // deixa o user escolher de novo (ou voltar pro residencial)
    await AppModeStore.clear();
    if (!context.mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const ModeSelectScreen()));
  }

  void _go(BuildContext context, Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  Widget _devPill(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: AppTheme.gold.withOpacity(.14),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: AppTheme.gold.withOpacity(.35)),
      ),
      child: Text(
        text,
        style: TextStyle(color: Colors.white.withOpacity(.9), fontWeight: FontWeight.w800, fontSize: 12),
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppTheme.border.withOpacity(.35)),
      ),
      child: child,
    );
  }

  Widget _tile({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.border.withOpacity(.35)),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppTheme.gold.withOpacity(.12),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppTheme.gold.withOpacity(.35)),
              ),
              child: Icon(icon, color: AppTheme.gold),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
                const SizedBox(height: 3),
                Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(.65), fontWeight: FontWeight.w600)),
              ]),
            ),
            Icon(Icons.chevron_right, color: Colors.white.withOpacity(.6)),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        backgroundColor: AppTheme.bg,
        elevation: 0,
        title: Row(
          children: [
            const Text('Modo Industrial'),
            const SizedBox(width: 10),
            _devPill('EM DESENVOLVIMENTO'),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Voltar',
            onPressed: () => _backToModeSelect(context),
            icon: const Icon(Icons.swap_horiz),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '⚠️ Área Industrial em construção',
                  style: TextStyle(color: Colors.white.withOpacity(.95), fontWeight: FontWeight.w900, fontSize: 16),
                ),
                const SizedBox(height: 8),
                Text(
                  'Você já pode testar algumas funções, mas essa área ainda está sendo refinada para ficar no nível “supervisor”.\n'
                  'Nada aqui é definitivo: layout, nomes, fluxo e relatórios vão evoluir.',
                  style: TextStyle(color: Colors.white.withOpacity(.75), fontWeight: FontWeight.w600, height: 1.25),
                ),
                const SizedBox(height: 12),
                Text(
                  'O que entra em breve:',
                  style: TextStyle(color: Colors.white.withOpacity(.9), fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 8),
                Text(
                  '• Mapa da fábrica (Área → Linha → Máquina)\n'
                  '• QR da máquina (abre checklist + histórico)\n'
                  '• Fechamento de turno com ranking + timeline\n'
                  '• Exportação padrão supervisor (PDF/CSV)\n'
                  '• Usuários por equipe + assinatura de registro',
                  style: TextStyle(color: Colors.white.withOpacity(.75), fontWeight: FontWeight.w700, height: 1.25),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => _go(context, const DiagnosisScreen()),
                        icon: const Icon(Icons.sensors_outlined),
                        label: const Text('Testar Diagnóstico'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _go(context, const LineStopScreen()),
                        icon: const Icon(Icons.report_problem_outlined),
                        label: const Text('Testar Linha Parou'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _go(context, const ChecklistsScreen()),
                        icon: const Icon(Icons.checklist_outlined),
                        label: const Text('Testar Checklists'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _go(context, const KnowledgeBaseScreen()),
                        icon: const Icon(Icons.library_books_outlined),
                        label: const Text('Falhas recorrentes'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          const SizedBox(height: 14),
          Text('Atalhos rápidos', style: TextStyle(color: Colors.white.withOpacity(.9), fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),

          _tile(
            context: context,
            icon: Icons.report_problem_outlined,
            title: 'LINHA PAROU 🚨',
            subtitle: 'Criar registro + copiar relatório.',
            onTap: () => _go(context, const LineStopScreen()),
          ),
          _tile(
            context: context,
            icon: Icons.sensors_outlined,
            title: 'Diagnóstico por sintoma',
            subtitle: 'Passo a passo por falha.',
            onTap: () => _go(context, const DiagnosisScreen()),
          ),
          _tile(
            context: context,
            icon: Icons.checklist_outlined,
            title: 'Checklists & LOTO',
            subtitle: 'Templates + salvar execução.',
            onTap: () => _go(context, const ChecklistsScreen()),
          ),
          _tile(
            context: context,
            icon: Icons.library_books_outlined,
            title: 'Base de conhecimento',
            subtitle: 'Falhas recorrentes com busca.',
            onTap: () => _go(context, const KnowledgeBaseScreen()),
          ),

          const SizedBox(height: 16),
          TextButton.icon(
            onPressed: () => _backToModeSelect(context),
            icon: const Icon(Icons.arrow_back),
            label: const Text('Voltar / Trocar modo'),
          ),
        ],
      ),
    );
  }
}
