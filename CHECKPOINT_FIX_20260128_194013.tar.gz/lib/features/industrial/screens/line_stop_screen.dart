import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../core/app_theme.dart';
import '../models/industrial_models.dart';
import '../services/industrial_store.dart';
import 'line_stop_history_screen.dart';

class LineStopScreen extends StatefulWidget {
  const LineStopScreen({super.key});

  @override
  State<LineStopScreen> createState() => _LineStopScreenState();
}

class _LineStopScreenState extends State<LineStopScreen> {
  int _step = 0;

  final _area = TextEditingController();
  final _machine = TextEditingController();
  final _symptom = TextEditingController();
  final _desc = TextEditingController();
  String _shift = 'A';

  final List<String> _tests = [];
  final _testCtrl = TextEditingController();

  final _cause = TextEditingController();
  final _action = TextEditingController();
  final _downtime = TextEditingController();
  final _prev = TextEditingController();

  String _reportText(LineStopReport r) {
    final dt = DateTime.fromMillisecondsSinceEpoch(r.ts);
    final tests = r.testsDone.isEmpty ? '—' : r.testsDone.map((e) => '• $e').join('\n');
    return ''
        'FG Elétrica • LINHA PAROU 🚨\n'
        'Data: ${dt.toString()}\n'
        'Área: ${r.area}\n'
        'Máquina: ${r.machine}\n'
        'Turno: ${r.shift}\n'
        'Sintoma: ${r.symptom}\n\n'
        'Descrição:\n${r.description.isEmpty ? '—' : r.description}\n\n'
        'Testes realizados:\n$tests\n\n'
        'Causa provável:\n${r.probableCause.isEmpty ? '—' : r.probableCause}\n\n'
        'Ação tomada:\n${r.actionTaken.isEmpty ? '—' : r.actionTaken}\n\n'
        'Tempo parado (min): ${r.downtimeMin.isEmpty ? '—' : r.downtimeMin}\n\n'
        'Prevenção:\n${r.prevention.isEmpty ? '—' : r.prevention}\n';
  }

  Future<void> _save() async {
    final r = LineStopReport(
      area: _area.text.trim(),
      machine: _machine.text.trim(),
      shift: _shift,
      symptom: _symptom.text.trim(),
      description: _desc.text.trim(),
      testsDone: List<String>.from(_tests),
      probableCause: _cause.text.trim(),
      actionTaken: _action.text.trim(),
      downtimeMin: _downtime.text.trim(),
      prevention: _prev.text.trim(),
    );

    await IndustrialStore.addLineStop(r);
    final txt = _reportText(r);

    if (!mounted) return;
    await Clipboard.setData(ClipboardData(text: txt));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Relatório salvo e copiado 📋')),
    );
    Navigator.pop(context);
  }

  @override
  void dispose() {
    _area.dispose();
    _machine.dispose();
    _symptom.dispose();
    _desc.dispose();
    _testCtrl.dispose();
    _cause.dispose();
    _action.dispose();
    _downtime.dispose();
    _prev.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final steps = <Step>[
      Step(
        title: const Text('Contexto'),
        isActive: _step >= 0,
        content: Column(
          children: [
            TextField(controller: _area, decoration: const InputDecoration(labelText: 'Área (ex: Enchedora, Rotuladora...)')),
            const SizedBox(height: 10),
            TextField(controller: _machine, decoration: const InputDecoration(labelText: 'Máquina/Linha (ex: Krones/KHS/Eletric 80...)')),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: _shift,
              decoration: const InputDecoration(labelText: 'Turno'),
              items: const [
                DropdownMenuItem(value: 'A', child: Text('Turno A')),
                DropdownMenuItem(value: 'B', child: Text('Turno B')),
                DropdownMenuItem(value: 'C', child: Text('Turno C')),
                DropdownMenuItem(value: 'D', child: Text('Turno D')),
              ],
              onChanged: (v) => setState(() => _shift = v ?? 'A'),
            ),
            const SizedBox(height: 10),
            TextField(controller: _symptom, decoration: const InputDecoration(labelText: 'Sintoma (ex: motor não parte, sensor falha...)')),
            const SizedBox(height: 10),
            TextField(controller: _desc, maxLines: 4, decoration: const InputDecoration(labelText: 'Descrição rápida do ocorrido')),
          ],
        ),
      ),
      Step(
        title: const Text('Testes feitos'),
        isActive: _step >= 1,
        content: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(controller: _testCtrl, decoration: const InputDecoration(labelText: 'Adicionar teste (ex: medi 24V no sensor)')),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () {
                    final t = _testCtrl.text.trim();
                    if (t.isEmpty) return;
                    setState(() {
                      _tests.add(t);
                      _testCtrl.clear();
                    });
                  },
                  child: const Text('Add'),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ..._tests.map((t) => ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: Text(t, style: TextStyle(color: Colors.white.withOpacity(.9), fontWeight: FontWeight.w700)),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => setState(() => _tests.remove(t)),
                  ),
                )),
            if (_tests.isEmpty)
              Text('Dica: coloca 3 a 5 testes principais.',
                  style: TextStyle(color: Colors.white.withOpacity(.7), fontWeight: FontWeight.w600)),
          ],
        ),
      ),
      Step(
        title: const Text('Fechamento'),
        isActive: _step >= 2,
        content: Column(
          children: [
            TextField(controller: _cause, maxLines: 3, decoration: const InputDecoration(labelText: 'Causa provável')),
            const SizedBox(height: 10),
            TextField(controller: _action, maxLines: 3, decoration: const InputDecoration(labelText: 'Ação tomada')),
            const SizedBox(height: 10),
            TextField(controller: _downtime, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Tempo parado (min)')),
            const SizedBox(height: 10),
            TextField(controller: _prev, maxLines: 3, decoration: const InputDecoration(labelText: 'Prevenção / observações')),
          ],
        ),
      ),
    ];

    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(backgroundColor: AppTheme.bg, title: const Text('LINHA PAROU 🚨')),
      body: Theme(
        data: Theme.of(context).copyWith(
          colorScheme: Theme.of(context).colorScheme.copyWith(primary: AppTheme.gold),
        ),
        child: Stepper(
          currentStep: _step,
          steps: steps,
          onStepContinue: () async {
            if (_step < steps.length - 1) {
              setState(() => _step++);
            } else {
              await _save();
            }
          },
          onStepCancel: () {
            if (_step > 0) setState(() => _step--);
          },
          controlsBuilder: (context, details) {
            final isLast = _step == steps.length - 1;
            return Row(
              children: [
                ElevatedButton(
                  onPressed: details.onStepContinue,
                  child: Text(isLast ? 'Salvar + Copiar' : 'Próximo'),
                ),
                const SizedBox(width: 12),
                TextButton(
                  onPressed: details.onStepCancel,
                  child: const Text('Voltar'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
