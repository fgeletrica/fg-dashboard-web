import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../../core/app_theme.dart';
import '../models/industrial_models.dart';

class LineStopDetailScreen extends StatelessWidget {
  final LineStopReport report;
  const LineStopDetailScreen({super.key, required this.report});

  String _reportText(LineStopReport r) {
    final dt = DateTime.fromMillisecondsSinceEpoch(r.ts);
    final tests = r.testsDone.isEmpty ? '—' : r.testsDone.map((e) => '• $e').join('\n');
    return ''
        'FG Elétrica • LINHA PAROU 🚨\n'
        'Data: ${dt.toString()}\n'
        'Área: ${r.area}\n'
        'Máquina: ${r.machine}\n'
        'Turno: ${r.shift}\n'
        'Sintoma: ${r.symptom}\n\n'
        'Descrição:\n${r.description.isEmpty ? '—' : r.description}\n\n'
        'Testes realizados:\n$tests\n\n'
        'Causa provável:\n${r.probableCause.isEmpty ? '—' : r.probableCause}\n\n'
        'Ação tomada:\n${r.actionTaken.isEmpty ? '—' : r.actionTaken}\n\n'
        'Tempo parado (min): ${r.downtimeMin.isEmpty ? '—' : r.downtimeMin}\n\n'
        'Prevenção:\n${r.prevention.isEmpty ? '—' : r.prevention}\n';
  }

  Widget _sec(String t, String b) {
    if (b.trim().isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppTheme.border.withOpacity(.35)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(t, style: TextStyle(color: Colors.white.withOpacity(.9), fontWeight: FontWeight.w900)),
          const SizedBox(height: 6),
          Text(b, style: TextStyle(color: Colors.white.withOpacity(.75), fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dt = DateTime.fromMillisecondsSinceEpoch(report.ts).toString().substring(0, 16);
    final tests = report.testsDone.isEmpty ? '' : report.testsDone.map((e) => '• $e').join('\n');

    return Scaffold(
      backgroundColor: AppTheme.bg,
      appBar: AppBar(
        backgroundColor: AppTheme.bg,
        title: const Text('Detalhe • Linha Parou'),
        actions: [
          IconButton(
            tooltip: 'Copiar',
            onPressed: () async {
              await Clipboard.setData(ClipboardData(text: _reportText(report)));
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copiado 📋')));
            },
            icon: const Icon(Icons.copy),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.card,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: AppTheme.border.withOpacity(.35)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  (report.machine.isEmpty ? 'Máquina' : report.machine) + ' • Turno ${report.shift}',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16),
                ),
                const SizedBox(height: 4),
                Text(
                  '${report.area.isEmpty ? 'Área' : report.area} • $dt',
                  style: TextStyle(color: Colors.white.withOpacity(.65), fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 10),
                Text(report.symptom.isEmpty ? 'Sem sintoma' : report.symptom,
                    style: TextStyle(color: Colors.white.withOpacity(.9), fontWeight: FontWeight.w800)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _sec('Descrição', report.description),
          if (tests.trim().isNotEmpty) _sec('Testes', tests),
          _sec('Causa provável', report.probableCause),
          _sec('Ação tomada', report.actionTaken),
          _sec('Tempo parado (min)', report.downtimeMin),
          _sec('Prevenção', report.prevention),
        ],
      ),
    );
  }
}
