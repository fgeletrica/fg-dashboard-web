import 'features/tests/dr_test_screen.dart';
import 'screens/mode_select_screen.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'screens/app_entry.dart';
import 'routes/app_pages.dart';
import 'routes/app_routes.dart';
import 'config/supabase_config.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('pt_BR', null);
  
  await Supabase.initialize(
    url: SupabaseConfig.url,
    anonKey: SupabaseConfig.anonKey,
  );

  runApp(const MeuAjudanteApp());
}

class MeuAjudanteApp extends StatelessWidget {
  const MeuAjudanteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: AppPages.routes,

debugShowCheckedModeBanner: false,
      title: 'FG Elétrica',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0E141E),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0E141E),
          foregroundColor: Colors.white,
        ),
      ),
      initialRoute: AppRoutes.authGate,

    );
  }
}
